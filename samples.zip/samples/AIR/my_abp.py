MAX = 99999
MIN = -99999

def abp(depth, nodeIndex, isMaxmizer, values, alpha, beta):
	if depth == 3:
		return values[nodeIndex] ####
	
	if isMaxmizer:
		best = MIN
		
		for i in range(0,2): 
			val = abp(depth+1, nodeIndex*2+i, False, values, alpha, beta)
			best = max(best, val)
			alpha = max(alpha,best)
			
			if alpha>=beta:
				break
		return best
		
	else:
		best = MAX
		
		for i in range(0,2): 
			val = abp(depth+1, nodeIndex*2+i, True, values, alpha, beta)
			best = min(best, val)
			alpha = min(alpha,best)
			
			if alpha>=beta:
				break
		return best
	
if __name__== "__main__":
	values = [3,5,6,9,1,2,0,-1]
	print("The optimal value is : ", abp(0,0,True,values,MIN,MAX))

