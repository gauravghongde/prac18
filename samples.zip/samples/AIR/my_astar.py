class Node:
	def __init__(self, f=0, g=99999, h=0, name=0):
		self.f = f
		self.g = g
		self.h = h
		self.name = name
	
	def setNeighbour(self, neighbour=[]):
		self.neighbour = neighbour

graph = [
[-1,1,4,-1,-1],
[1,-1,2,5,12],
[4,2,-1,2,-1],
[-1,5,2,-1,3],
[-1,12,-1,3,-1]
]

heuristic = [7,6,2,1,0]

s = Node(h=heuristic[0], name=0)
a = Node(h=heuristic[1], name=1)
b = Node(h=heuristic[2], name=2)
c = Node(h=heuristic[3], name=3)
d = Node(h=heuristic[4], name=4)

s.setNeighbour([a,b])
a.setNeighbour([s,b,c,d])
b.setNeighbour([s,a,c])
c.setNeighbour([a,b,d])
d.setNeighbour([a,c])

def astar(start, goal):
	start.g = 0
	start.f = start.h
	cameFrom = {}
	openList = set([start])
	closedList = set([]) 
	
	while len(openList)!=0:
		current = findNodeWithLowestF(openList)
		
		if current == goal:
			print(constructPath(cameFrom, current))
		
		openList.remove(current)
		closedList.add(current)
		
		for neighbour in current.neighbour:
			if neighbour in closedList:
				continue
			if neighbour not in openList:
				openList.add(neighbour)
				
			tentativeG = current.g + graph[current.name][neighbour.name]
			if tentativeG>=neighbour.g:
				continue
			cameFrom[neighbour] = current
			neighbour.g = tentativeG
			neighbour.f = neighbour.h + neighbour.g
	return -1
	
def findNodeWithLowestF(openList):
	fValue = 99999
	node = None ##########
	for eachNode in openList:
		if fValue>eachNode.f:
			fValue = eachNode.f
			node = eachNode
	return node

def constructPath(cameFrom, current):
	fPath = []
	fPath.append(current.name)
	while current in cameFrom.keys():
		current = cameFrom[current]
		fPath.append(current.name)
		#print(current.name)
	return fPath

if __name__ == "__main__":
	path = astar(s,d)

