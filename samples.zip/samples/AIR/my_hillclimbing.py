def count(arr):
	cnt = 0
	for i in range(0,len(arr)-1):
		for j in range(i+1,len(arr)):
			if(arr[j]<arr[i]):
				cnt = cnt+1
	return cnt
	
def swap(arr, i, j):
	temp = arr[i]
	arr[i] = arr[j]
	arr[j] = temp
	return arr

if __name__ == "__main__":
	arr = [10,5,15,12,30]
	c = count(arr)
	while c>0:
		for i in range(0,len(arr)-1):
			arr = swap(arr,i,i+1)
			c1 = count(arr)
			if c1<c:
				c = c1
			else:
				arr = swap(arr,i,i+1)
	print(arr)
	
