n = 8
a = [[0 for x in range(n)] for y in range(n)]
b = {}

def isColSafe(row, col):
	while row>=0:
		if a[row][col] == 1:
			return 0
		row = row-1
	return 1
	
def isLDiagSafe(row, col):
	while row>=0 and col>=0:
		if a[row][col] == 1:
			return 0
		row = row-1
		col = col-1
	return 1
	
def isRDiagSafe(row, col):
	while row>=0 and col<n:
		if a[row][col] == 1:
			return 0
		row = row-1
		col = col+1
	return 1

def isSafe(row, col):
	if isColSafe(row, col)==0:
		return 0
	if isLDiagSafe(row, col)==0:
		return 0
	if isRDiagSafe(row, col)==0:
		return 0
	return 1

def solve(row, col):
	if row>=n:
		return
	p = 0
	while col<n:
		p = isSafe(row,col)
		if p==1:
			a[row][col] = 1
			b[row] = col
			break
		col = col+1 ##########
	if p==1:
		solve(row+1,0)
	else:  #########################
		a[row-1][b[row-1]] = 0
		solve(row-1,b[row-1]+1) ######

if __name__ == "__main__":
	solve(0,0)
	for i in a:
		print(i, "")
