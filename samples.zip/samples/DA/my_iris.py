import matplotlib.pyplot as plt
import pandas as pd
import pylab

df = pd.read_csv("iris.csv",header=None)
header = ["sepalLength","sepalWidth","petalLength","petalWidth","class"]
df.columns = header
# Describe 
print (df.describe())
print (df.dtypes)

# histogram
df.hist(color = ["yellow"])
plt.show()

df.boxplot()
plt.show()

'''
Also possible
plt.scatter(df.sepalLength , df.sepalWidth)
'''
plt.scatter(df.sepalLength,df.sepalWidth,df.petalLength,df.petalWidth)


plt.show()

