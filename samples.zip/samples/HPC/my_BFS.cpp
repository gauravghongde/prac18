#include<iostream>
#include<queue>

using namespace std;

struct node{
	struct node * left;
	struct node * right;
	int data;
};

class BFS{
	public://///////////////
	struct node * root;
	void traverse(node*);
	void insert(int);
	
	BFS(){
		root = NULL;////////////////
	}
};

void BFS::insert(int data){
	if(root==NULL){
		root = new node();
		root->left = root->right = NULL;
		root->data = data;
	}
	else{
		node * temp = root;
		node * parent;//////////////////////////////////////
		while(temp!=NULL){
			if(temp->data>data){
				parent = temp;
				temp=temp->left;
			}
			else{
				parent = temp;
				temp=temp->right;
			}
		}
		
		node * nn = new node();
		nn->left = nn->right = NULL;
		nn->data = data;
		 
		if(parent->data>data)
			parent->left = nn;
		else
			parent->right = nn;
	}
}

void BFS::traverse(node * root){
	queue<node *> q;
	q.push(root);
	int qSize;//////////////////////////////////
	
	while(!q.empty()){
		qSize = q.size();
		
		#pragma omp parallel for
		for(int i=0; i<qSize; i++){
			node * cn;
			#pragma omp critical
			{
				cn = q.front();
				q.pop();
				cout<<"\t"<<cn->data;
			}
			#pragma omp critical
			{
				if(cn->left!=NULL)
					q.push(cn->left);
				if(cn->right!=NULL)
					q.push(cn->right);
			}
		}
	}
}

int main(){
	BFS b;
	char ch; 
	int data;
	while(true){
		cout<<"\nEnter data: ";
		cin>>data;
		b.insert(data);
		cout<<"\ncontinue??: ";
		cin>>ch;
		if(ch=='n')
			break;
	}
	b.traverse(b.root);
}


