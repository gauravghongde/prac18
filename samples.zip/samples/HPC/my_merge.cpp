#include<iostream>
using namespace std;

void merge(int arr[], int mid, int l, int r){
	int n1,n2;
	int *L,*R;
	n1 = mid-l+1; /////////////////////////////
	n2 = r-mid; ///////////////////////////////
	L = new int[n1];
	R = new int[n2];
	
	for(int i=0; i<n1; i++)
		L[i] = arr[l+i];
		
	for(int j=0; j<n2; j++)
		R[j] = arr[mid+1+j];
		
		
	int i=0;
	int j=0;
	int k=l; /////#$#$rw3IMPIMP
		
	while(i<n1 && j<n2){
		if(L[i]<=R[j]){
			arr[k] = L[i];
			i++;
		}
		else{
			arr[k] = R[j];
			j++;
		}
		k++;
	}
	while(i<n1){
		arr[k] = L[i];
		i++;
		k++;
	}
	while(j<n2){
		arr[k] = R[j];
		j++;
		k++;
	}
}

void mergeSort(int arr[], int l, int r){
	int mid;
	if(l<r){
		mid = (l+r)/2;
		#pragma omp parallel sections
		{
			#pragma omp section
			{
				mergeSort(arr, l, mid);
			}
			
			#pragma omp section
			{
				mergeSort(arr, mid+1, r);
			}	
		}
		merge(arr,mid,l,r);
	}
}

int main(){
	int size;
	int * arr;
	cout<<"Enter size: ";
	cin>>size;
	arr = new int[size];
	
	for(int i=0; i<size; i++)
		cin>>arr[i];
	cout<<"UNSorted Array:\t";
	
	for(int i=0; i<size; i++)
		cout<<arr[i]<<" ";
		
	mergeSort(arr,0,size-1);
	
	cout<<"\nSorted Array:\t";
	for(int i=0; i<size; i++)
		cout<<arr[i]<<" ";
}
