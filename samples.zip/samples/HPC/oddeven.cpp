#include<iostream>
#include <cstdlib>

using namespace std;
#define N 20

void oddeven(int *a){
	int i,j,temp;
	for(i=0;i<N;i++){    
        if(i%2==0){
            #pragma omp parallel for
            for(j=0;j<N-1;j+=2){
                if(a[j]> a[j+1]){
                    temp = a[j];
                    a[j] = a[j+1];
                    a[j+1] = temp;
                }
            }
        }
        
        else{
            #pragma omp parallel for 
            for(j=1;j<N-1;j+=2){
                if(a[j]> a[j+1]){
                    temp = a[j];
                    a[j] = a[j+1];
                    a[j+1] = temp;
                }
            }
        }
        
    }
}

int main(){
	int *a;
	int size = N*sizeof(int);
	a = (int*)malloc(size);
	
	for(int i=0; i<N; i++){
		a[i] = rand()%N;
		//a[i] = i+1;
	}
	
	for(int i=0; i<N; i++){
		cout<<a[i]<<" ";
	}
	cout<<endl;
	
	oddeven(a);
	
	for(int i=0; i<N; i++){
		cout<<a[i]<<" ";
	}
}
